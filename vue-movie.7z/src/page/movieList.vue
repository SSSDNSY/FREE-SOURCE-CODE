<template lang="html">
	<ul class="cont-ul clear">
		<li class="cont-li b1" v-for="item in movieList" @click="goToInfo(item)">
			<div class="img-con">
				<img class="movie-img" v-bind:src="item.pic" />
			</div>
			<div class="movie-msg clear">
				<p class="movie-name">{{item.moviename}}</p>
				<p class="movie-price r1">
					<span>评分 </span>{{item.movieid}}</p>
			</div>
		</li>
	</ul>
</template>

<script>
	export default {
		data() {
			return {
				movieList: [],
			};
		},
		mounted() {
			this.$emit('setNav', ['兰州热播电影', 1]);

			// 这个是vue的钩子函数，当new Vue()实例创建完毕后执行的函数
			this.$http.jsonp("https://api.jisuapi.com/movie/on?cityid=&city=兰州&date=&appkey=389e9bc6a4f49803").then(res => {
				this.movieList = res.data.result.list;
				for (var i in this.movieList) {
					this.http({
						url: i.pic,
						method: 'GET',
						headers: {
							'content-Type': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8'
						}
					});
				}
				window.console.log(res.data)
				res = null;
			}).catch(error => {
				window.console.log("http error" + error);
			});
		},
		methods: {
			goToInfo(info) {
				//这里因为我想把整个对象传给详情页，所以使用的是session
				sessionStorage.setItem('movieInfo', JSON.stringify(info));
				this.$router.push({
					path: '/movieInfo', //路径
					name: 'movieInfo', //配置路由时的name
				});
			}
		}
	};
</script>

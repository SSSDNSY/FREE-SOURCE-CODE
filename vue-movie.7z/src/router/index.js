import Vue from 'vue/dist/vue.esm.js'
import Router from 'vue-router' /* 引用vue路由模块，并赋值给变量Router */
 
import movieList from '@/page/movieList.vue'
import movieInfo from '@/page/movieInfo.vue'
 
Vue.use(Router) /* 使用路由 */
 
export default new Router({
  routes: [ /* 进行路由配置，规定“/”引入到组件 */
    {
      path: '/',//默认页面
      name: 'movieList',
      component: movieList  /* 注册组件 */
    },
    {
      path: '/movieList',
      name: 'movieList',
      component: movieList
    },
    {
      path: '/movieInfo',
      name: 'movieInfo',
      component: movieInfo
    }
  ]
})

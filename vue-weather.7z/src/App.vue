<template>
    <div id="app" :class="imgClass">
        <main>
            <div class="search-box">
                <input
                        v-model="query"
                        @keypress="fetchWeather"
                        type="text"
                        class="search-bar"
                        placeholder="Search...">
            </div>

            <div class="weather-wrap" v-if="typeof  weather.main != 'undefined'">
                <div class="location-box">
                    <div class="location">{{weather.name}},{{weather.sys.country}}</div>
                    <div class="date">{{new Date()}}</div>
                </div>
                <div class="weather-box">
                    <div class="temp">{{Math.round(weather.main.temp)}}</div>
                    <div class="weather">{{weather.weather[0].main}}</div>
                </div>
            </div>

        </main>
    </div>
</template>

<script>
    export default {
        name: 'App',
        data() {
            return {
                imgClass: '',
                apiKey: "cf1b6920bfc248bb4e60836d22333e79",
                urlBase: 'http://api.openweathermap.org/data/2.5/',
                query: '',
                weather: {}
            }
        },
        methods: {
            fetchWeather(e) {
                if (e.key == 'Enter') {
                    fetch(`${this.urlBase}weather?q=${this.query}&units=metric&APPID=${this.apiKey}`)
                        .then(res => {
                            return res.json()
                        }).then(this.setResult)
                }
            },
            setResult(result) {
                console.log((this.result))
                this.weather = result

                this.imgClass = this.changeImg(this.weather)
            },
            changeImg() {
                let type = this.weather.weather[0].main || "default"
                switch (type) {
                    case "Clear":
                        return "clear";
                    case "Clouds":
                        return "clouds";
                    case "Snow":
                        return "snow";
                    case "Rain":
                        return "rain";
                    case "Mist":
                        return "mist";
                    case "Thunderstorm":
                        return "thunderstorm";
                    default:
                        return "default"
                }
            },
            dateBuilder() {
                // let date = new Date()
                // let month = [""]
                // let week = [""]
            }
        }
    }
</script>

<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;

    }

    body {
        font-family: 'montserrat', sans-serif;
    }

    #app {
        background-image: url("./assets/default.jpg");
        background-size: cover;
        background-position: bottom;
        transition: 0.4s;
    }

    #app.default {
        background-image: url("./assets/default.jpg");
    }

    #app.clouds {
        background-image: url("./assets/clouds-bg.jpg");
    }

    #app.mist {
        background-image: url("./assets/mist-bg.jpg");
    }

    #app.clear {
        background-image: url("./assets/clear-bg.jpg");
    }

    #app.snow {
        background-image: url("./assets/snow-bg.jpg");
    }

    #app.thunderstorm {
        background-image: url("./assets/thunderstorm-bg.jpg");
    }

    #app.rain {
        background-image: url("./assets/rain-bg.jpg");
    }

    main {
        min-height: 100vh;
        padding: 25px;
        background-image: linear-gradient(to bottom, rgba(0, 0, 0, 0.25), rgba(0, 0, 0.0 .75));
    }

    .search-box {
        width: 100%;
        margin-bottom: 30px;
    }

    .search-box .search-bar {
        display: block;
        width: 100%;
        padding: 15px;

        color: #313131;
        font-size: 20px;
        appearance: none;
        border: none;
        outline: none;
        box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.25);
        background: rgba(255, 255, 255, 0.5);
        border-radius: 0px 16px 0px 16px;

    }

    .search-box .search-bar:focus {
        background-color: rgba(255, 255, 255, 0.75);
        border-radius: 16px 0px 16px 0px;
        box-shadow: 0px 0px 16px rgba(0, 0, 0, 0.25);
    }

    .location-box {
        text-align: center;
    }

    .location-box .location {
        color: #fff;
        font-size: 32px;
        font-weight: 500;
        text-shadow: 1px 3px rgba(0, 0, 0, 0.25);
    }

    .location-box .date {
        color: #fff;
        font-size: 20px;
        font-weight: 300;
        font-style: italic;
    }

    .weather-box {
        text-align: center;
    }

    .weather-box .temp {
        display: inline-block;
        padding: 10px 25px;
        color: #fff;
        font-size: 102px;
        font-weight: 900;

        box-shadow: 3px 6px rgba(0, 0, 0, 0.25);
        background-color: rgba(255, 255, 255, 0.25);

        border-radius: 16px;
        margin: 30px 0px;
    }

    .weather-box .weather {
        color: white;
        font-size: 48px;
        font-weight: 700;
        font-style: italic;
    }
    /*.weather {*/
    /*    box-shadow: 3px 6px rgba(0, 0, 0, 0.25);*/
    /*}*/
</style>

#!/bin/sh

set -e
. /etc/profile

OS_NAME=$(uname -s)
JB_PRODUCTS="idea clion phpstorm goland pycharm webstorm rider datagrip rubymine appcode dataspell gateway jetbrains_client"

if [ $OS_NAME == "Darwin" ]; then
  PROFILE_PATH="${HOME}/.bash_profile"
else
  PROFILE_PATH="${HOME}/.bashrc"
fi

MY_VMOPTIONS_SHELL_FILE="${HOME}/.jetbrains.vmoptions.sh"

for PRD in $JB_PRODUCTS; do
  ENV_NAME=$(echo $PRD | tr '[a-z]' '[A-Z]')"_VM_OPTIONS"
  if [ $OS_NAME == "Darwin" ]; then
    launchctl unsetenv $ENV_NAME
    sed -i '' '/___MY_VMOPTIONS_SHELL_FILE="${HOME}\/\.jetbrains\.vmoptions\.sh"; if /d' "${PROFILE_PATH}" >/dev/null 2>&1
  else
    sed -i '/___MY_VMOPTIONS_SHELL_FILE="${HOME}\/\.jetbrains\.vmoptions\.sh"; if /d' "${PROFILE_PATH}" >/dev/null 2>&1
  fi

  rm -rf "$MY_VMOPTIONS_SHELL_FILE"
done

echo 'done.'

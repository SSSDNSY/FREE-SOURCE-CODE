#!/bin/sh

set -e
. /etc/profile

OS_NAME=$(uname -s)
JB_PRODUCTS="idea clion phpstorm goland pycharm webstorm rider datagrip rubymine appcode dataspell gateway jetbrains_client"

BASE_PATH=$(dirname $(
  cd $(dirname "$0")
  pwd
))

JAR_FILE_PATH="${BASE_PATH}/ja-netfilter.jar"

if [ ! -f "${JAR_FILE_PATH}" ]; then
  echo 'ja-netfilter.jar not found'
  exit -1
fi

if [ $OS_NAME == "Darwin" ]; then
  PROFILE_PATH="${HOME}/.bash_profile"
else
  PROFILE_PATH="${HOME}/.bashrc"
fi

MY_VMOPTIONS_SHELL_FILE="${HOME}/.jetbrains.vmoptions.sh"
echo '#!/bin/sh' >"${MY_VMOPTIONS_SHELL_FILE}"

EXEC_LINE='___MY_VMOPTIONS_SHELL_FILE="${HOME}/.jetbrains.vmoptions.sh"; if [ -f "${___MY_VMOPTIONS_SHELL_FILE}" ]; then . "${___MY_VMOPTIONS_SHELL_FILE}"; fi'

for PRD in $JB_PRODUCTS; do
  VM_FILE_PATH="${BASE_PATH}/vmoptions/${PRD}.vmoptions"
  if [ ! -f "${VM_FILE_PATH}" ]; then
    continue
  fi

  if [ $OS_NAME == "Darwin" ]; then
    sed -i '' '/^\-javaagent:\/.*\/ja\-netfilter\.jar/d' "${VM_FILE_PATH}"
  else
    sed -i '/^\-javaagent:\/.*\/ja\-netfilter\.jar/d' "${VM_FILE_PATH}"
  fi

  echo "-javaagent:${JAR_FILE_PATH}" >>"${VM_FILE_PATH}"

  ENV_NAME=$(echo $PRD | tr '[a-z]' '[A-Z]')"_VM_OPTIONS"
  echo "export ${ENV_NAME}=\"${VM_FILE_PATH}\"" >>"${MY_VMOPTIONS_SHELL_FILE}"

  if [ $OS_NAME == "Darwin" ]; then
    launchctl setenv $ENV_NAME "${VM_FILE_PATH}"
  fi

  if [ $OS_NAME == "Darwin" ]; then
    sed -i '' '/___MY_VMOPTIONS_SHELL_FILE="${HOME}\/\.jetbrains\.vmoptions\.sh"; if /d' "${PROFILE_PATH}" >/dev/null 2>&1
  else
    sed -i '/___MY_VMOPTIONS_SHELL_FILE="${HOME}\/\.jetbrains\.vmoptions\.sh"; if /d' "${PROFILE_PATH}" >/dev/null 2>&1
  fi

  echo $EXEC_LINE >>"${PROFILE_PATH}"
done

echo 'done.'

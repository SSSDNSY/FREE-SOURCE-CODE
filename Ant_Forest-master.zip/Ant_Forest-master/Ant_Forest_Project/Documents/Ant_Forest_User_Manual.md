# User_Manual
User manual for alipay ant forest auto-collect script (Ant_Forest)  
  
##### _I'm trying to build it..._

将"Ant_Forest_Project"目录放置在设备本地存储中  
使用"Auto.js"运行"Ant_Forest_Launcher.js"即可
let PWMAP = require("../Modules/MODULE_PWMAP.js");
new PWMAP().pwmapDecrypt();
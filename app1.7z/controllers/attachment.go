package controllers

import (
	"github.com/astaxie/beego"
	"io"
	"net/url"
	"os"
)

type AttachmentController struct {
	beego.Controller
}

func (this *AttachmentController) Get(){
	this.Data["IsFile"] = true
	filePath,err := url.QueryUnescape(this.Ctx.Request.RequestURI[1:])
	if len(filePath)>1 && filePath !="file"{
	if nil!=err {
		beego.Error(err)
		return
	}
	f,err:=os.Open(filePath)
	if nil!=err {
		beego.Error(err)
		return
	}
	defer f.Close()
	_,err=io.Copy(this.Ctx.ResponseWriter,f)
	if nil!=err {
		beego.Error(err)
		return
	}}else {
		this.TplName="file_list.html"
	}
}
package controllers

import (
	"app1/models"
	"github.com/astaxie/beego"
)

type ReplyController struct {
	beego.Controller
}

func (this *ReplyController) Get() {
	this.Data["IsLogin"] = checkAccount(this.Ctx)
	this.Data["IsTopic"] = true
	this.TplName = "topic.html"
	topics, err := models.GetAllTopic("","",false)
	if nil != err {
		beego.Error(err.Error())
	} else {
		this.Data["Topics"] = topics
	}
}

func (this *ReplyController) Add() {
	this.Data["IsLogin"] = checkAccount(this.Ctx)
	this.Data["IsTopic"] = true

	tid := this.Input().Get("tid")
	err := models.AddReply(tid, this.Input().Get("nickName"),
		this.Input().Get("content"))
	if nil != err {
		beego.Error(err.Error())
	}
	this.Redirect("/topic/view/"+tid, 302)
}

func (this *ReplyController) Delete() {
	if !checkAccount(this.Ctx){
		return
	}
	this.Data["IsLogin"] = checkAccount(this.Ctx)
	this.Data["IsTopic"] = true

	tid := this.Input().Get("tid")
	err := models.DelReply(this.Input().Get("rid"))
	if nil != err {
		beego.Error(err.Error())
	}
	this.Redirect("/topic/view/"+tid, 302)
}

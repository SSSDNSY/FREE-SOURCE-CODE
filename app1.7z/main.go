package main

import (
	"app1/controllers"
	"app1/models"
	_ "app1/routers"
	"fmt"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/orm"
	"time"
)

func init() {
	models.RegisterDB()
}

func main() {

	//i18n.SetMessage(lang, "conf/"+"locale_"+lang+".ini");
	time.Local = time.FixedZone("CST", 3600*8)
	//timelocal = time.LoadLocation("Asia/Chongqing") //方法2
	fmt.Println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>", time.Now().Local())
	orm.Debug = true
	orm.RunSyncdb("default", false, true)
	beego.Router("/", &controllers.Home{})
	beego.Run()
}

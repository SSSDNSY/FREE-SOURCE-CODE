const app = getApp()
const FileSystemManager = wx.getFileSystemManager()
const ctx = wx.createCanvasContext('srcImg')
Page({
  data: {
    lastFile: "",
    clipImg:""
  },
  chooseImg: function(e) { ///////////////选择用户本地图片并保存
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: function(res) {
        const chooseImgPaht = res.tempFilePaths[0]
        const chooseFile = res.tempFiles[0]
        console.log(res)
        wx.saveFile({
          tempFilePath: chooseImgPaht,
          success(res) {
            const savedFilePath = res.savedFilePath
          }
        })
        console.log("保存chooseImg路径：chooseImgPaht" + chooseImgPaht)
        wx.setStorage({
          key: 'chooseImgPaht',
          data: chooseImgPaht,
        })
      },
      fail: function(res) {
        console.log('获取用户图片失败' + res)
      },
      complete: function(res) {
        console.log('获取用户图片complete' + res)
      },
    })
  },
  getSavedImg: function (e) { ///////////////获取已经保存的图片
    let that = this;
    wx.getSavedFileList({
      success(res) {
        if (res.fileList.length===0){
          console.log(' getSavedImg 获取chooseImg的文件为空！' )
          return
        }
        that.setData({
          lastFile: res.fileList[res.fileList.length - 1]
        })
        console.log(' getSavedImg 获取chooseImg的文件 ' + that.data.lastFile.filePath)
      }
    })
  
    
  },
  clipImage: function () {///////////////裁剪图片
    let that = this;
    wx.getStorage({
      key: 'chooseImgPaht',
      success: function(res) {
        console.log("获取裁剪chooseImgPaht" + Object.getOwnPropertyDescriptors(res) )
      },
    })
    if(!that.data.lastFile){
      console.log(' clipImage 获取filePath为空！')
      return
    }
    ctx.drawImage(that.data.lastFile.filePath, 0, 0, 150, 100)
    ctx.draw()
    setTimeout(() => {
      wx.canvasToTempFilePath({
        canvasId: 'srcImg',
        x: 10,
        y: 10,
        width: 20,
        height: 20,
        destWidth: 35,
        destHeight: 30,
        // fileType: this.imgtype,
        success: (res) => {
          that.setData({
            clipImg : res.tempFilePath
          })   
          console.log("裁剪图片canvasToTempFilePath" + Object.getOwnPropertyDescriptors(res))
          wx.setStorage({
            key: 'tempFilePaths',
            data: [res.tempFilePath],
            success: (i) => {
             console.log("save i"+i)
            }
          })
        
        }
      })
    }, 500)
  }
})
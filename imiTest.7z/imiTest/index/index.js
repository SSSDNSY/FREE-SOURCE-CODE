const app = getApp()
const FileSystemManager = wx.getFileSystemManager()
Page({
  data: {
    lastFile: ""
  },
  chooseImg: function(e) { //选择用户本地图片并保存
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: function(res) {
        const chooseImgPaht = res.tempFilePaths[0]
        const chooseFile = res.tempFiles[0]
        console.log(res)
        wx.saveFile({
          tempFilePath: chooseImgPaht,
          success(res) {
            const savedFilePath = res.savedFilePath
          }
        })
      },
      fail: function(res) {
        console.log('获取用户图片失败' + res)
      },
      complete: function(res) {
        console.log('获取用户图片complete' + res)
      },
    })
  },
  getSavedImg: function(e) { //获取已经保存的图片
    let that = this;
    wx.getSavedFileList({
      success(res) {
        that.setData({
          lastFile: res.fileList[res.fileList.length - 1]
        })
        console.log('获取本地已保存的文件列表' + that.data.lastFile.filePath)
      }
    })
    FileSystemManager.readFile({
      filePath: that.data.lastFile.filePath,

      success(res1) {
        console.log(res1)
        var buffer = res1.data// new ArrayBuffer(32);
        var blob = new Blob([buffer]);  
      },
      fail(e) {

      },
      complete(e) {

      }
    })
  }
})